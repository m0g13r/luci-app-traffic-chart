# luci-app-traffic-chart (0.9.0, beta)

Live and historic traffic view for OpenWrt routers running SQM, with special
support for Qualcomm NSS hardware offload.

* Per application, device and destination, live and as history
  (5 min / hourly / daily buckets, optionally persisted to USB/NAS)
* Byte counts come from conntrack, application names from netifyd (optional)
* Shaper health: drops, ECN marks, backlog (nsstbl/nssifb, cake, htb+fq_codel)
* `nss-rk.qos`: SQM script for NSS with 17 port based traffic classes

## Requirements

`luci-base`, `rpcd`, `sqm-scripts`, `nftables`, `jsonfilter`, `tc` (tc-tiny/full).
Optional: `socat` + `netifyd` (application names), `conntrack`.
NSS shaper additionally needs an NSS build with `nss-ifb` / `nsstbl` / `nssfq_codel`.

## Install

Build as luci package (`Makefile` included) or copy the files:

| file | destination |
|---|---|
| trafficchart | /etc/init.d/trafficchart (chmod +x) |
| trafficchart.config | /etc/config/trafficchart |
| trafficchart-agg, -apps, -common, -hosts, -tc, -v6prefixes | /usr/libexec/ (chmod +x) |
| luci.trafficchart | /usr/libexec/rpcd/luci.trafficchart (chmod +x) |
| luci-app-traffic-chart.json | /usr/share/rpcd/acl.d/ |
| luci-app-traffic-chart_menu.json | /usr/share/luci/menu.d/luci-app-traffic-chart.json |
| traffic_chart.js, trafficchart_config.js | /www/luci-static/resources/view/network/ |
| nss-rk.qos, nss-rk.qos.help | /usr/lib/sqm/ |

Then `/etc/init.d/trafficchart enable; /etc/init.d/rpcd restart; /etc/init.d/trafficchart start`.

## Behaviour worth knowing

* **NSS offload:** accelerated flows are not classified again, so their kernel
  mark/DSCP stays as it was. The chart demotes big WEB/P2P/BE flows to BULK
  itself, so it can show BULK while the kernel mark is still WEB.
* **One SQM instance** with NSS (single `nssifb`, single nft table).
  The generic backend supports several queues.
* **Marks:** only the low byte is used, other bits are preserved.
  Restarting the classifier zeroes the whole conntrack mark (`conntrack -U -m 0`).
* **DNS redirect and TTL rewrite** are OFF by default
  (`dns_redirect`, `dns_redirect_exclude`, `ttl_fix`), see `nss-rk.qos.help`.
* `attr_ports` empty = every port except `attr_skip_ports`.

## Changes vs. previous internal version

* attr_ports default was 9999 (own proxy), now empty
* nss-rk.qos: marks preserved outside the low byte; DNS redirect and TTL rewrite optional and off by default;
  TCP/53 now PRIO; warning if several SQM queues are enabled
* history reply capped at 800 kB (ubus limit)
* trafficchart-hosts no longer prints unused FDB lines
* CSS typo fixed, shipped profile is `low-cpu` like the daemon default

## License

TODO: choose a license (nss-rk.qos is derived from simple.qos / nss.qos, check
their licenses first) and set `PKG_LICENSE` in the Makefile.
